/*
  Archivo: frontend/src/i18n/ui-translator.js
  Propósito: Módulo que traduce dinámicamente el contenido de la página HTML
             buscando elementos con atributos 'data-i18n-key'. Se activa al
             cargar la página y cada vez que el idioma cambia.
*/

const UITranslator = (function () {
  'use strict';

  /**
   * @private
   * Recorre el DOM y traduce todos los elementos que tienen el atributo 'data-i18n-key'.
   * También traduce atributos como 'title' o 'placeholder' si se especifica.
   */
  function translatePage() {
    console.log('Traductor UI: Iniciando traducción de la página...');
    const elementsToTranslate = document.querySelectorAll('[data-i18n-key]');

    elementsToTranslate.forEach(element => {
      const key = element.dataset.i18nKey;
      // Busca un atributo 'data-i18n-target' para saber si traducir el contenido o un atributo.
      const targetAttribute = element.dataset.i18nTarget;
      const translation = TranslationService.t(key);

      if (targetAttribute) {
        // Si el target es 'title', 'placeholder', etc., se traduce ese atributo.
        element.setAttribute(targetAttribute, translation);
      } else {
        // Por defecto, se traduce el contenido de texto (textContent).
        element.textContent = translation;
      }
    });
    console.log(`Traductor UI: Se procesaron ${elementsToTranslate.length} elementos.`);
  }

  /**
   * Inicializa el módulo, realiza la primera traducción y se suscribe
   * a los cambios de idioma para futuras traducciones.
   */
  function initialize() {
    try {
      translatePage();
      
      EventBus.subscribe('language:changed', translatePage);
      
      console.log('Módulo Traductor UI inicializado y escuchando cambios de idioma.');
    } catch (error) {
      console.error('Error al inicializar el Traductor UI.', error);
    }
  }

  return {
    initialize,
  };
})();