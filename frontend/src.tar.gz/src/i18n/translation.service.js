/*
  Archivo: frontend/src/i18n/translation.service.js
  Propósito: Servicio principal que carga y provee las traducciones de la interfaz
             de usuario desde los archivos JSON de localización.
*/

const TranslationService = (function () {
  'use strict';
  
  const AVAILABLE_LANGUAGES = {
    'es': 'Español',
    'en': 'English'
  };

  let current_language_strings = {};

  async function loadLanguage(language_code) {
    try {
      const response = await fetch(`../src/i18n/locales/${language_code}.json`);
      if (!response.ok) {
        throw new Error(`Respuesta de red no fue ok para: ${language_code}`);
      }
      current_language_strings = await response.json();
      console.log(`Servicio de Traducción: Idioma '${language_code}' cargado exitosamente.`);
    } catch (error) {
      console.error(`Error crítico al cargar el idioma ${language_code}:`, error);
      // Propagamos el error para que sea capturado por la función que lo llamó.
      throw error;
    }
  }

  async function initialize(language_code = 'es') {
    try {
        await loadLanguage(language_code);
    } catch (error) {
        console.error("No se pudo cargar el idioma inicial. La interfaz puede no tener texto.");
        current_language_strings = {};
    }
  }

  /**
   * Cambia el idioma actual de la aplicación, recarga las traducciones y notifica a la UI.
   * AHORA CON MANEJO DE ERRORES Y NOTIFICACIONES.
   * @param {string} new_language_code - El nuevo código de idioma a establecer.
   */
  async function changeLanguage(new_language_code) {
    try {
      console.log(`Servicio de Traducción: Solicitud de cambio de idioma a '${new_language_code}'.`);
      await loadLanguage(new_language_code);
      
      LanguageDetector.saveLanguagePreference(new_language_code);
      document.documentElement.lang = new_language_code;
      
      // Notificar a toda la aplicación que el idioma ha cambiado.
      EventBus.publish('language:changed', { lang: new_language_code });
      
      // Notificar al usuario que el cambio fue exitoso.
      ToastHandler.showToast(TranslationService.t('toast_language_changed_successfully'));

    } catch (error) {
      // Si ocurre un error (como el de CORS), se notificará al usuario.
      console.error('Fallo en la operación de cambio de idioma.', error);
      ToastHandler.showToast(TranslationService.t('toast_language_change_error'));
    }
  }
  
  function translate(key) {
    return current_language_strings[key] || `[${key}]`;
  }
  
  const t = translate;

  function getAvailableLanguages() {
    return AVAILABLE_LANGUAGES;
  }

  return {
    initialize,
    changeLanguage,
    translate,
    t,
    getAvailableLanguages,
  };
})();