/*
  Archivo: frontend/src/i18n/language-detector.js
  Propósito: Detecta el idioma del navegador del usuario la primera vez que visita
             y gestiona la persistencia de la preferencia de idioma.
*/

const LanguageDetector = (function () {
  'use strict';

  const SUPPORTED_LANGUAGES = ['en', 'es'];
  const DEFAULT_LANGUAGE = 'es';
  const LOCAL_STORAGE_KEY = 'user_preferred_language';

  /**
   * Obtiene el idioma guardado en localStorage.
   * @private
   * @returns {string|null} El código del idioma guardado o null si no existe.
   */
  function getSavedLanguage() {
    try {
      return localStorage.getItem(LOCAL_STORAGE_KEY);
    } catch (error) {
      console.warn('No se pudo acceder a localStorage para obtener el idioma.', error);
      return null;
    }
  }

  /**
   * Detecta el idioma del navegador del usuario.
   * @private
   * @returns {string} El código de idioma de dos letras (ej. 'en', 'es').
   */
  function getBrowserLanguage() {
    const lang = navigator.language || navigator.userLanguage;
    if (lang) {
      const primaryLang = lang.split('-')[0];
      if (SUPPORTED_LANGUAGES.includes(primaryLang)) {
        return primaryLang;
      }
    }
    return DEFAULT_LANGUAGE;
  }

  /**
   * Determina el idioma inicial para la aplicación.
   * La prioridad es: 1. Idioma guardado, 2. Idioma del navegador, 3. Idioma por defecto.
   * @returns {string} El código de idioma a utilizar.
   */
  function detectInitialLanguage() {
    const savedLang = getSavedLanguage();
    if (savedLang && SUPPORTED_LANGUAGES.includes(savedLang)) {
      console.log(`Detector de Idioma: Se encontró el idioma guardado '${savedLang}'.`);
      return savedLang;
    }

    const browserLang = getBrowserLanguage();
    console.log(`Detector de Idioma: Se detectó el idioma del navegador '${browserLang}'.`);
    return browserLang;
  }

  /**
   * Guarda la preferencia de idioma del usuario en localStorage.
   * @param {string} languageCode - El código del idioma a guardar (ej. 'es').
   */
  function saveLanguagePreference(languageCode) {
    if (!SUPPORTED_LANGUAGES.includes(languageCode)) {
      console.error(`Se intentó guardar un idioma no soportado: ${languageCode}`);
      return;
    }
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, languageCode);
      console.log(`Detector de Idioma: Preferencia de idioma '${languageCode}' guardada.`);
    } catch (error) {
      console.error('No se pudo guardar la preferencia de idioma en localStorage.', error);
    }
  }

  return {
    detectInitialLanguage,
    saveLanguagePreference,
  };
})();